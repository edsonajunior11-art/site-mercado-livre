const texto = document.getElementById("texto");
const texto1 = document.getElementById("texto1");
const produto1 =["6137Taup2AL.jpg","fone-sem-fio-c3tech-bluetooth-5-1-branco-ep-tws-21wh-001.jpg", "regular-camiseta-0000-brilho-contraste-1-copiar-26.webp",]
const produto2 =["-7596799.jpg","meia-02150-2668-01.webp","jor4743.webp"]
const nomes1 = ["Parafusadeira e Furadeira à Bateria 12V BPF-12K3, Kit de 13 Acessórios e Maleta, Empunhadura Emborrachada, Bivolt","Fone De Ouvido Sem Fio Bluetooth 5.3 Compatível iPhone Android Com Microfone e Redução de Ruído Wireless Academia Corrida Musicas Graves Potentes Controle Touch,À Prova D'água HiFi Branco","Camiseta Masculina Algodão Premium Básicas Lisas"]
const nomes2 = ["Tênis Nike Feminino Revolution 6 Corrida","Meia Masculina Cano Longo - Preto","Cinto Preto"]
const preço1 = ["210,00", "70,00", "60,00"]
const preço2 = ["269,99","20,00","40,00" ]

for(let i=0; i < produto1.length; i++){
    texto.innerHTML += `<div class="caixa">
    <img class= img src="${produto1[i]}"><br>
    <h1 class= h1>OFERTA DO DIA</h1>
    <h1 class= textao >${nomes1[i]} </h1> <br>
    <h1 class= valor >R$: ${preço1[i]} </h1> <br>
    <div class= gratis>
    <h1 class= chegara >Chegará grátis amanhã </h1>
    <img class= img1 src="full.png">
    </div>
    </div>`;
}
for(let i=0; i < produto2.length; i++){
    texto1.innerHTML +=`<div class="caixa">
    <img class= img2 src="${produto2[i]}"><br>
    <h1 class= h1>OFERTA DO DIA</h1>
    <h1 class= textao >${nomes2[i]} </h1> <br>
    <h1 class= valor >R$: ${preço2[i]} </h1> <br>
    <div class= gratis>
    <h1 class= chegara > Chegará grátis amanhã </h1>
    <img class= img1 src= "full.png">
    </div>
    </div>`;
}
